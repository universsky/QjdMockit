﻿(function () {
  'use strict';

  var system = adv.system;
  system
    .controller('system', function ($scope) {
     
    });
})();
